"""DEPRECATED - This module is kept here only as a backward compatibility shim
for the old ufoLib.etree module, which was moved to fontTools.misc.etree.
Please use the latter instead.
"""
from fontTools.misc.etree import *
